package modconv;

import com.gibox.tool.ModelConverter;
import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/**
 * Standalone desktop front-end for ModGlass's PC-mod -> mobile conversion (the GIBox "Unity2" converter).
 * Output is a folder containing model.json + model.bin (+ conversion.log), exactly what the app's own
 * converter writes.
 */
public final class Main {
    static void usage() {
        System.err.println(String.join("\n",
            "ModConv - 3DMigoto/PC mod -> ModGlass mobile model (model.json + model.bin)",
            "",
            "用法 / Usage:",
            "  java -jar modconv.jar --ini <mod.ini> --id <角色ID> --out <输出目录> [选项]",
            "",
            "必需:",
            "  --ini <file>        PC 模组的主 INI（模组文件夹整体作为输入，INI 所在目录为根）",
            "  --id <int>          目标角色 ID，8 位，10000000-10001999（例：10000112）",
            "  --out <dir>         输出目录（须为新目录，或加 --replace）",
            "",
            "可选:",
            "  --skeleton <dir>    角色骨骼库目录（手机端 Unity2 骨骼同步得到）。不给则按索引转换并启用 Body 回退",
            "  --mapping \"A=Body;B=Head\"  部件映射（与 App 里“部件映射”一致）",
            "  --fallback <name>   无骨骼库时的回退部件名（默认 Body）",
            "  --no-variants       不展开 INI 的按键/变体组合（默认展开，与 App 一致）",
            "  --replace           输出目录已存在时替换",
            "  -v                  打印转换日志"));
    }

    public static void main(String[] a) throws Exception {
        System.setOut(new java.io.PrintStream(new java.io.FileOutputStream(java.io.FileDescriptor.out), true, "UTF-8"));
        System.setErr(new java.io.PrintStream(new java.io.FileOutputStream(java.io.FileDescriptor.err), true, "UTF-8"));
        File ini = null, out = null, skeleton = null;
        int id = 0;
        String mapping = "", fallback = null;
        boolean variants = true, replace = false, verbose = false;
        for (int i = 0; i < a.length; i++) {
            switch (a[i]) {
                case "--ini": ini = new File(a[++i]); break;
                case "--out": out = new File(a[++i]); break;
                case "--id": id = Integer.parseInt(a[++i]); break;
                case "--skeleton": skeleton = new File(a[++i]); break;
                case "--mapping": mapping = a[++i]; break;
                case "--fallback": fallback = a[++i]; break;
                case "--no-variants": variants = false; break;
                case "--replace": replace = true; break;
                case "-v": verbose = true; break;
                case "-h": case "--help": usage(); return;
                default: System.err.println("未知参数: " + a[i]); usage(); System.exit(2);
            }
        }
        if (ini == null || out == null || id == 0) { usage(); System.exit(2); }
        if (id < 10000000 || id > 10001999) { System.err.println("角色 ID 超出范围 (10000000-10001999)"); System.exit(2); }
        ini = ini.getCanonicalFile();
        if (!ini.isFile()) { System.err.println("找不到 INI: " + ini); System.exit(2); }
        if (skeleton != null && !skeleton.isDirectory()) { System.err.println("骨骼库目录不存在: " + skeleton); System.exit(2); }
        out = out.getAbsoluteFile();
        if (out.getParentFile() != null) out.getParentFile().mkdirs();

        ModelConverter.Options opt = new ModelConverter.Options().ini(ini).mapping(mapping).variants(variants).replace(replace);
        if (skeleton == null) opt.fallback(fallback != null ? fallback : "Body");
        else if (fallback != null) opt.fallback(fallback);

        StringBuilder log = new StringBuilder();
        log.append(skeleton == null ? "无骨骼库：单 INI 按索引转换，需进游戏验证。\n" : "已使用角色骨骼库，未识别部件需要明确映射。\n");
        try {
            ModelConverter.convert(ini.getParentFile(), skeleton, out, id, opt, new TextureDecoders(), log);
        } catch (Exception e) {
            if (verbose) System.err.println(log);
            System.err.println("转换失败：" + e.getMessage());
            if (verbose) e.printStackTrace();
            System.exit(1);
        }
        Files.write(new File(out, "conversion.log").toPath(), log.toString().getBytes("UTF-8"));
        if (verbose) System.out.println(log);
        File bin = new File(out, "model.bin");
        System.out.println("完成: " + out + "  (model.json + model.bin " + bin.length() + " bytes)");
    }
}
