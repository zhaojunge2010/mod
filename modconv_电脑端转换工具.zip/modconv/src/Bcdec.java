package modconv;

/**
 * Java port of the BC1-BC5 and BC7 block decoders from bcdec (https://github.com/iOrange/bcdec),
 * commit 80859ed3b7afb1c527a2a99d70c61457bea72d0c, the same version ModGlass ships.
 * bcdec is MIT / Unlicense (see LICENSE-bcdec.txt). Every block decodes to 16 RGBA pixels (64 bytes, row-major).
 */
final class Bcdec {
    private Bcdec() {}

    private static int u16(byte[] d, int o) { return (d[o] & 0xff) | (d[o + 1] & 0xff) << 8; }
    private static int u32(byte[] d, int o) { return u16(d, o) | u16(d, o + 2) << 16; }
    private static long u64(byte[] d, int o) { return (u32(d, o) & 0xffffffffL) | (long) u32(d, o + 4) << 32; }

    private static void colorBlock(byte[] src, int so, byte[] dst, boolean onlyOpaque) {
        int c0 = u16(src, so), c1 = u16(src, so + 2);
        int r0 = (c0 >> 11) & 0x1f, g0 = (c0 >> 5) & 0x3f, b0 = c0 & 0x1f;
        int r1 = (c1 >> 11) & 0x1f, g1 = (c1 >> 5) & 0x3f, b1 = c1 & 0x1f;
        int[][] ref = new int[4][];
        ref[0] = new int[] {(r0 * 527 + 23) >> 6, (g0 * 259 + 33) >> 6, (b0 * 527 + 23) >> 6, 255};
        ref[1] = new int[] {(r1 * 527 + 23) >> 6, (g1 * 259 + 33) >> 6, (b1 * 527 + 23) >> 6, 255};
        if (c0 > c1 || onlyOpaque) {
            ref[2] = new int[] {((2 * r0 + r1) * 351 + 61) >> 7, ((2 * g0 + g1) * 2763 + 1039) >> 11, ((2 * b0 + b1) * 351 + 61) >> 7, 255};
            ref[3] = new int[] {((r0 + r1 * 2) * 351 + 61) >> 7, ((g0 + g1 * 2) * 2763 + 1039) >> 11, ((b0 + b1 * 2) * 351 + 61) >> 7, 255};
        } else {
            ref[2] = new int[] {((r0 + r1) * 1053 + 125) >> 8, ((g0 + g1) * 4145 + 1019) >> 11, ((b0 + b1) * 1053 + 125) >> 8, 255};
            ref[3] = new int[] {0, 0, 0, 0};
        }
        int idx = u32(src, so + 4);
        for (int p = 0; p < 16; p++, idx >>>= 2) {
            int[] c = ref[idx & 3];
            dst[p * 4] = (byte) c[0]; dst[p * 4 + 1] = (byte) c[1]; dst[p * 4 + 2] = (byte) c[2]; dst[p * 4 + 3] = (byte) c[3];
        }
    }

    private static void sharpAlpha(byte[] src, int so, byte[] dst) {
        for (int i = 0; i < 4; i++) {
            int a = u16(src, so + i * 2);
            for (int j = 0; j < 4; j++) dst[(i * 4 + j) * 4 + 3] = (byte) (((a >> (4 * j)) & 0x0f) * 17);
        }
    }

    /** Writes the interpolated 8-bit channel into dst at byte offset (pixel*stride + ch). */
    private static void smoothAlpha(byte[] src, int so, byte[] dst, int stride, int ch) {
        long block = u64(src, so);
        int a0 = (int) (block & 0xff), a1 = (int) ((block >> 8) & 0xff);
        int[] a = new int[8];
        a[0] = a0; a[1] = a1;
        if (a0 > a1) {
            a[2] = (6 * a0 + a1) / 7; a[3] = (5 * a0 + 2 * a1) / 7; a[4] = (4 * a0 + 3 * a1) / 7;
            a[5] = (3 * a0 + 4 * a1) / 7; a[6] = (2 * a0 + 5 * a1) / 7; a[7] = (a0 + 6 * a1) / 7;
        } else {
            a[2] = (4 * a0 + a1) / 5; a[3] = (3 * a0 + 2 * a1) / 5; a[4] = (2 * a0 + 3 * a1) / 5;
            a[5] = (a0 + 4 * a1) / 5; a[6] = 0; a[7] = 255;
        }
        long idx = block >>> 16;
        for (int p = 0; p < 16; p++, idx >>>= 3) dst[p * stride + ch] = (byte) a[(int) (idx & 7)];
    }

    static void bc1(byte[] s, int o, byte[] dst) { colorBlock(s, o, dst, false); }
    static void bc2(byte[] s, int o, byte[] dst) { colorBlock(s, o + 8, dst, true); sharpAlpha(s, o, dst); }
    static void bc3(byte[] s, int o, byte[] dst) { colorBlock(s, o + 8, dst, true); smoothAlpha(s, o, dst, 4, 3); }

    /** Single channel -> grey RGB, opaque. */
    static void bc4(byte[] s, int o, byte[] dst) {
        byte[] t = new byte[16];
        smoothAlpha(s, o, t, 1, 0);
        for (int p = 0; p < 16; p++) { dst[p * 4] = t[p]; dst[p * 4 + 1] = t[p]; dst[p * 4 + 2] = t[p]; dst[p * 4 + 3] = (byte) 255; }
    }

    /** Two channels -> R,G ; B=0 ; A=255. */
    static void bc5(byte[] s, int o, byte[] dst) {
        byte[] r = new byte[16], g = new byte[16];
        smoothAlpha(s, o, r, 1, 0);
        smoothAlpha(s, o + 8, g, 1, 0);
        for (int p = 0; p < 16; p++) { dst[p * 4] = r[p]; dst[p * 4 + 1] = g[p]; dst[p * 4 + 2] = 0; dst[p * 4 + 3] = (byte) 255; }
    }

    // ---- BC7 ----
    private static final byte[] ACTUAL_RGB = {4, 6, 5, 7, 5, 7, 7, 5};
    private static final byte[] ACTUAL_A = {0, 0, 0, 0, 6, 8, 7, 5};
    private static final int[] W2 = {0, 21, 43, 64};
    private static final int[] W3 = {0, 9, 18, 27, 37, 46, 55, 64};
    private static final int[] W4 = {0, 4, 9, 13, 17, 21, 26, 30, 34, 38, 43, 47, 51, 55, 60, 64};
    private static final int HAS_PBITS = 0b11001011;
    /** [subsets-2][partition][row][col] flattened; bit 0x80 marks the fix-up index. */
    private static final int[] PARTITIONS = {
        128,0,1,1,0,0,1,1,0,0,1,1,0,0,1,129,
        128,0,0,1,0,0,0,1,0,0,0,1,0,0,0,129,
        128,1,1,1,0,1,1,1,0,1,1,1,0,1,1,129,
        128,0,0,1,0,0,1,1,0,0,1,1,0,1,1,129,
        128,0,0,0,0,0,0,1,0,0,0,1,0,0,1,129,
        128,0,1,1,0,1,1,1,0,1,1,1,1,1,1,129,
        128,0,0,1,0,0,1,1,0,1,1,1,1,1,1,129,
        128,0,0,0,0,0,0,1,0,0,1,1,0,1,1,129,
        128,0,0,0,0,0,0,0,0,0,0,1,0,0,1,129,
        128,0,1,1,0,1,1,1,1,1,1,1,1,1,1,129,
        128,0,0,0,0,0,0,1,0,1,1,1,1,1,1,129,
        128,0,0,0,0,0,0,0,0,0,0,1,0,1,1,129,
        128,0,0,1,0,1,1,1,1,1,1,1,1,1,1,129,
        128,0,0,0,0,0,0,0,1,1,1,1,1,1,1,129,
        128,0,0,0,1,1,1,1,1,1,1,1,1,1,1,129,
        128,0,0,0,0,0,0,0,0,0,0,0,1,1,1,129,
        128,0,0,0,1,0,0,0,1,1,1,0,1,1,1,129,
        128,1,129,1,0,0,0,1,0,0,0,0,0,0,0,0,
        128,0,0,0,0,0,0,0,129,0,0,0,1,1,1,0,
        128,1,129,1,0,0,1,1,0,0,0,1,0,0,0,0,
        128,0,129,1,0,0,0,1,0,0,0,0,0,0,0,0,
        128,0,0,0,1,0,0,0,129,1,0,0,1,1,1,0,
        128,0,0,0,0,0,0,0,129,0,0,0,1,1,0,0,
        128,1,1,1,0,0,1,1,0,0,1,1,0,0,0,129,
        128,0,129,1,0,0,0,1,0,0,0,1,0,0,0,0,
        128,0,0,0,1,0,0,0,129,0,0,0,1,1,0,0,
        128,1,129,0,0,1,1,0,0,1,1,0,0,1,1,0,
        128,0,129,1,0,1,1,0,0,1,1,0,1,1,0,0,
        128,0,0,1,0,1,1,1,129,1,1,0,1,0,0,0,
        128,0,0,0,1,1,1,1,129,1,1,1,0,0,0,0,
        128,1,129,1,0,0,0,1,1,0,0,0,1,1,1,0,
        128,0,129,1,1,0,0,1,1,0,0,1,1,1,0,0,
        128,1,0,1,0,1,0,1,0,1,0,1,0,1,0,129,
        128,0,0,0,1,1,1,1,0,0,0,0,1,1,1,129,
        128,1,0,1,1,0,129,0,0,1,0,1,1,0,1,0,
        128,0,1,1,0,0,1,1,129,1,0,0,1,1,0,0,
        128,0,129,1,1,1,0,0,0,0,1,1,1,1,0,0,
        128,1,0,1,0,1,0,1,129,0,1,0,1,0,1,0,
        128,1,1,0,1,0,0,1,0,1,1,0,1,0,0,129,
        128,1,0,1,1,0,1,0,1,0,1,0,0,1,0,129,
        128,1,129,1,0,0,1,1,1,1,0,0,1,1,1,0,
        128,0,0,1,0,0,1,1,129,1,0,0,1,0,0,0,
        128,0,129,1,0,0,1,0,0,1,0,0,1,1,0,0,
        128,0,129,1,1,0,1,1,1,1,0,1,1,1,0,0,
        128,1,129,0,1,0,0,1,1,0,0,1,0,1,1,0,
        128,0,1,1,1,1,0,0,1,1,0,0,0,0,1,129,
        128,1,1,0,0,1,1,0,1,0,0,1,1,0,0,129,
        128,0,0,0,0,1,129,0,0,1,1,0,0,0,0,0,
        128,1,0,0,1,1,129,0,0,1,0,0,0,0,0,0,
        128,0,129,0,0,1,1,1,0,0,1,0,0,0,0,0,
        128,0,0,0,0,0,129,0,0,1,1,1,0,0,1,0,
        128,0,0,0,0,1,0,0,129,1,1,0,0,1,0,0,
        128,1,1,0,1,1,0,0,1,0,0,1,0,0,1,129,
        128,0,1,1,0,1,1,0,1,1,0,0,1,0,0,129,
        128,1,129,0,0,0,1,1,1,0,0,1,1,1,0,0,
        128,0,129,1,1,0,0,1,1,1,0,0,0,1,1,0,
        128,1,1,0,1,1,0,0,1,1,0,0,1,0,0,129,
        128,1,1,0,0,0,1,1,0,0,1,1,1,0,0,129,
        128,1,1,1,1,1,1,0,1,0,0,0,0,0,0,129,
        128,0,0,1,1,0,0,0,1,1,1,0,0,1,1,129,
        128,0,0,0,1,1,1,1,0,0,1,1,0,0,1,129,
        128,0,129,1,0,0,1,1,1,1,1,1,0,0,0,0,
        128,0,129,0,0,0,1,0,1,1,1,0,1,1,1,0,
        128,1,0,0,0,1,0,0,0,1,1,1,0,1,1,129,
        128,0,1,129,0,0,1,1,0,2,2,1,2,2,2,130,
        128,0,0,129,0,0,1,1,130,2,1,1,2,2,2,1,
        128,0,0,0,2,0,0,1,130,2,1,1,2,2,1,129,
        128,2,2,130,0,0,2,2,0,0,1,1,0,1,1,129,
        128,0,0,0,0,0,0,0,129,1,2,2,1,1,2,130,
        128,0,1,129,0,0,1,1,0,0,2,2,0,0,2,130,
        128,0,2,130,0,0,2,2,1,1,1,1,1,1,1,129,
        128,0,1,1,0,0,1,1,130,2,1,1,2,2,1,129,
        128,0,0,0,0,0,0,0,129,1,1,1,2,2,2,130,
        128,0,0,0,1,1,1,1,129,1,1,1,2,2,2,130,
        128,0,0,0,1,1,129,1,2,2,2,2,2,2,2,130,
        128,0,1,2,0,0,129,2,0,0,1,2,0,0,1,130,
        128,1,1,2,0,1,129,2,0,1,1,2,0,1,1,130,
        128,1,2,2,0,129,2,2,0,1,2,2,0,1,2,130,
        128,0,1,129,0,1,1,2,1,1,2,2,1,2,2,130,
        128,0,1,129,2,0,0,1,130,2,0,0,2,2,2,0,
        128,0,0,129,0,0,1,1,0,1,1,2,1,1,2,130,
        128,1,1,129,0,0,1,1,130,0,0,1,2,2,0,0,
        128,0,0,0,1,1,2,2,129,1,2,2,1,1,2,130,
        128,0,2,130,0,0,2,2,0,0,2,2,1,1,1,129,
        128,1,1,129,0,1,1,1,0,2,2,2,0,2,2,130,
        128,0,0,129,0,0,0,1,130,2,2,1,2,2,2,1,
        128,0,0,0,0,0,129,1,0,1,2,2,0,1,2,130,
        128,0,0,0,1,1,0,0,130,2,129,0,2,2,1,0,
        128,1,2,130,0,129,2,2,0,0,1,1,0,0,0,0,
        128,0,1,2,0,0,1,2,129,1,2,2,2,2,2,130,
        128,1,1,0,1,2,130,1,129,2,2,1,0,1,1,0,
        128,0,0,0,0,1,129,0,1,2,130,1,1,2,2,1,
        128,0,2,2,1,1,0,2,129,1,0,2,0,0,2,130,
        128,1,1,0,0,129,1,0,2,0,0,2,2,2,2,130,
        128,0,1,1,0,1,2,2,0,1,130,2,0,0,1,129,
        128,0,0,0,2,0,0,0,130,2,1,1,2,2,2,129,
        128,0,0,0,0,0,0,2,129,1,2,2,1,2,2,130,
        128,2,2,130,0,0,2,2,0,0,1,2,0,0,1,129,
        128,0,1,129,0,0,1,2,0,0,2,2,0,2,2,130,
        128,1,2,0,0,129,2,0,0,1,130,0,0,1,2,0,
        128,0,0,0,1,1,129,1,2,2,130,2,0,0,0,0,
        128,1,2,0,1,2,0,1,130,0,129,2,0,1,2,0,
        128,1,2,0,2,0,1,2,129,130,0,1,0,1,2,0,
        128,0,1,1,2,2,0,0,1,1,130,2,0,0,1,129,
        128,0,1,1,1,1,130,2,2,2,0,0,0,0,1,129,
        128,1,0,129,0,1,0,1,2,2,2,2,2,2,2,130,
        128,0,0,0,0,0,0,0,130,1,2,1,2,1,2,129,
        128,0,2,2,1,129,2,2,0,0,2,2,1,1,2,130,
        128,0,2,130,0,0,1,1,0,0,2,2,0,0,1,129,
        128,2,2,0,1,2,130,1,0,2,2,0,1,2,2,129,
        128,1,0,1,2,2,130,2,2,2,2,2,0,1,0,129,
        128,0,0,0,2,1,2,1,130,1,2,1,2,1,2,129,
        128,1,0,129,0,1,0,1,0,1,0,1,2,2,2,130,
        128,2,2,130,0,1,1,1,0,2,2,2,0,1,1,129,
        128,0,0,2,1,129,1,2,0,0,0,2,1,1,1,130,
        128,0,0,0,2,129,1,2,2,1,1,2,2,1,1,130,
        128,2,2,2,0,129,1,1,0,1,1,1,0,2,2,130,
        128,0,0,2,1,1,1,2,129,1,1,2,0,0,0,130,
        128,1,1,0,0,129,1,0,0,1,1,0,2,2,2,130,
        128,0,0,0,0,0,0,0,2,1,129,2,2,1,1,130,
        128,1,1,0,0,129,1,0,2,2,2,2,2,2,2,130,
        128,0,2,2,0,0,1,1,0,0,129,1,0,0,2,130,
        128,0,2,2,1,1,2,2,129,1,2,2,0,0,2,130,
        128,0,0,0,0,0,0,0,0,0,0,0,2,129,1,130,
        128,0,0,130,0,0,0,1,0,0,0,2,0,0,0,129,
        128,2,2,2,1,2,2,2,0,2,2,2,129,2,2,130,
        128,1,0,129,2,2,2,2,2,2,2,2,2,2,2,130,
        128,1,1,129,2,0,1,1,130,2,0,1,2,2,2,0
    };

    private static final class Bits {
        long low, high;
        int read(int n) {
            int mask = (1 << n) - 1;
            int bits = (int) (low & mask);
            low >>>= n;
            low |= ((high & mask) << (64 - n));
            high >>>= n;
            return bits;
        }
    }

    private static int interp(int a, int b, int[] w, int idx) { return (a * (64 - w[idx]) + b * w[idx] + 32) >> 6; }

    static void bc7(byte[] src, int so, byte[] dst) {
        Bits bs = new Bits();
        bs.low = u64(src, so); bs.high = u64(src, so + 8);
        int mode = 0;
        while (mode < 8 && bs.read(1) == 0) mode++;
        if (mode >= 8) { java.util.Arrays.fill(dst, 0, 64, (byte) 0); return; }
        int partition = 0, numParts = 1, rotation = 0, indexSel = 0;
        if (mode == 0 || mode == 1 || mode == 2 || mode == 3 || mode == 7) {
            numParts = (mode == 0 || mode == 2) ? 3 : 2;
            partition = bs.read(mode == 0 ? 4 : 6);
        }
        int numEp = numParts * 2;
        if (mode == 4 || mode == 5) {
            rotation = bs.read(2);
            if (mode == 4) indexSel = bs.read(1);
        }
        int[][] ep = new int[6][4];
        for (int i = 0; i < 3; i++) for (int j = 0; j < numEp; j++) ep[j][i] = bs.read(ACTUAL_RGB[mode]);
        if (ACTUAL_A[mode] > 0) for (int j = 0; j < numEp; j++) ep[j][3] = bs.read(ACTUAL_A[mode]);
        if (mode == 0 || mode == 1 || mode == 3 || mode == 6 || mode == 7) {
            for (int i = 0; i < numEp; i++) for (int j = 0; j < 4; j++) ep[i][j] <<= 1;
            if (mode == 1) {
                int i = bs.read(1), j = bs.read(1);
                for (int k = 0; k < 3; k++) { ep[0][k] |= i; ep[1][k] |= i; ep[2][k] |= j; ep[3][k] |= j; }
            } else if ((HAS_PBITS & (1 << mode)) != 0) {
                for (int i = 0; i < numEp; i++) { int j = bs.read(1); for (int k = 0; k < 4; k++) ep[i][k] |= j; }
            }
        }
        for (int i = 0; i < numEp; i++) {
            int j = ACTUAL_RGB[mode] + ((HAS_PBITS >> mode) & 1);
            for (int k = 0; k < 3; k++) { ep[i][k] = ep[i][k] << (8 - j); ep[i][k] |= ep[i][k] >> j; }
            j = ACTUAL_A[mode] + ((HAS_PBITS >> mode) & 1);
            ep[i][3] = ep[i][3] << (8 - j); ep[i][3] |= ep[i][3] >> j;
        }
        if (ACTUAL_A[mode] == 0) for (int j = 0; j < numEp; j++) ep[j][3] = 0xff;

        int indexBits = (mode == 0 || mode == 1) ? 3 : (mode == 6 ? 4 : 2);
        int indexBits2 = mode == 4 ? 3 : (mode == 5 ? 2 : 0);
        int[] weights = indexBits == 2 ? W2 : (indexBits == 3 ? W3 : W4);
        int[] weights2 = indexBits2 == 2 ? W2 : W3;

        int[] indices = new int[16];
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) {
            int ps = numParts == 1 ? (((i | j) != 0) ? 0 : 128) : PARTITIONS[((numParts - 2) * 64 + partition) * 16 + i * 4 + j];
            int ib = indexBits;
            if ((ps & 0x80) != 0) ib--;
            indices[i * 4 + j] = bs.read(ib);
        }
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) {
            int ps = numParts == 1 ? (((i | j) != 0) ? 0 : 128) : PARTITIONS[((numParts - 2) * 64 + partition) * 16 + i * 4 + j];
            ps &= 3;
            int index = indices[i * 4 + j];
            int[] e0 = ep[ps * 2], e1 = ep[ps * 2 + 1];
            int r, g, b, a;
            if (indexBits2 == 0) {
                r = interp(e0[0], e1[0], weights, index); g = interp(e0[1], e1[1], weights, index);
                b = interp(e0[2], e1[2], weights, index); a = interp(e0[3], e1[3], weights, index);
            } else {
                int index2 = bs.read(((i | j) != 0) ? indexBits2 : indexBits2 - 1);
                if (indexSel == 0) {
                    r = interp(e0[0], e1[0], weights, index); g = interp(e0[1], e1[1], weights, index);
                    b = interp(e0[2], e1[2], weights, index); a = interp(e0[3], e1[3], weights2, index2);
                } else {
                    r = interp(e0[0], e1[0], weights2, index2); g = interp(e0[1], e1[1], weights2, index2);
                    b = interp(e0[2], e1[2], weights2, index2); a = interp(e0[3], e1[3], weights, index);
                }
            }
            int t;
            switch (rotation) {
                case 1: t = a; a = r; r = t; break;
                case 2: t = a; a = g; g = t; break;
                case 3: t = a; a = b; b = t; break;
                default: break;
            }
            int o = (i * 4 + j) * 4;
            dst[o] = (byte) r; dst[o + 1] = (byte) g; dst[o + 2] = (byte) b; dst[o + 3] = (byte) a;
        }
    }
}
