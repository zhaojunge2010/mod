package modconv;

import com.gibox.tool.ModelConverter;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import javax.imageio.ImageIO;

/**
 * Desktop replacement for the APK's native texture decoder (libmodglass_unity2.so / NativeBridge).
 * Returns: int32 width, int32 height (little endian), then width*height*4 bytes RGBA (R,G,B,A).
 * PNG goes through ImageIO; DDS is decoded here (single 2D texture, mip 0 only).
 */
public final class TextureDecoders implements ModelConverter.TextureDecoder {
    @Override
    public byte[] decode(byte[] in) throws Exception {
        if (in.length >= 8 && (in[0] & 0xff) == 0x89 && in[1] == 'P' && in[2] == 'N' && in[3] == 'G') return png(in);
        return dds(in);
    }

    private static byte[] pack(int w, int h, byte[] rgba) {
        if (w <= 0 || h <= 0 || w > 8192 || h > 8192) throw new IllegalArgumentException("纹理尺寸无效 " + w + "x" + h);
        ByteBuffer b = ByteBuffer.allocate(8 + rgba.length).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(w).putInt(h).put(rgba);
        return b.array();
    }

    private static byte[] png(byte[] in) throws Exception {
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(in));
        if (img == null) throw new IllegalArgumentException("PNG 纹理解码失败");
        int w = img.getWidth(), h = img.getHeight();
        byte[] out = new byte[w * h * 4];
        int[] row = new int[w];
        int o = 0;
        for (int y = 0; y < h; y++) {
            img.getRGB(0, y, w, 1, row, 0, w); // non-premultiplied ARGB
            for (int x = 0; x < w; x++) {
                int p = row[x];
                out[o++] = (byte) (p >>> 16); out[o++] = (byte) (p >>> 8); out[o++] = (byte) p; out[o++] = (byte) (p >>> 24);
            }
        }
        return pack(w, h, out);
    }

    private static int le32(byte[] d, int o) {
        return (d[o] & 0xff) | (d[o + 1] & 0xff) << 8 | (d[o + 2] & 0xff) << 16 | (d[o + 3] & 0xff) << 24;
    }

    // DXGI formats
    static final int R8G8B8A8_UNORM = 28, R8G8B8A8_SRGB = 29, B8G8R8A8_UNORM = 87, B8G8R8X8_UNORM = 88,
            B8G8R8A8_SRGB = 91, B8G8R8X8_SRGB = 93, R8_UNORM = 61;

    private static byte[] dds(byte[] d) {
        if (d.length < 128 || le32(d, 0) != 0x20534444 || le32(d, 4) != 124) throw new IllegalArgumentException("Invalid DDS header");
        int h = le32(d, 12), w = le32(d, 16);
        int caps2 = le32(d, 112);
        if ((caps2 & 0x200) != 0 || (caps2 & 0x200000) != 0) throw new IllegalArgumentException("DDS must be a single 2D texture");
        int pfFlags = le32(d, 80), fourcc = le32(d, 84), bits = le32(d, 88);
        int rm = le32(d, 92), gm = le32(d, 96), bm = le32(d, 100), am = le32(d, 104);
        int off = 128;
        String codec = null; // BC1..BC7
        int dxgi = 0;
        if ((pfFlags & 4) != 0) {
            switch (fourcc) {
                case 0x31545844: codec = "BC1"; break; // DXT1
                case 0x33545844: case 0x32545844: codec = "BC2"; break; // DXT3/2
                case 0x35545844: case 0x34545844: codec = "BC3"; break; // DXT5/4
                case 0x31495441: case 0x55344342: codec = "BC4"; break; // ATI1 / BC4U
                case 0x32495441: case 0x55354342: codec = "BC5"; break; // ATI2 / BC5U
                case 0x30315844: { // DX10
                    if (d.length < 148) throw new IllegalArgumentException("Short DDS DX10");
                    dxgi = le32(d, 128);
                    off = 148;
                    if (le32(d, 132) != 3 /*TEXTURE2D*/ || le32(d, 140) > 1 || (le32(d, 136) & 4) != 0) throw new IllegalArgumentException("DDS must be a single 2D texture");
                    switch (dxgi) {
                        case 70: case 71: case 72: codec = "BC1"; break;
                        case 73: case 74: case 75: codec = "BC2"; break;
                        case 76: case 77: case 78: codec = "BC3"; break;
                        case 79: case 80: case 81: codec = "BC4"; break;
                        case 82: case 83: case 84: codec = "BC5"; break;
                                                case 97: case 98: case 99: codec = "BC7"; break;
                        case R8G8B8A8_UNORM: case R8G8B8A8_SRGB: case B8G8R8A8_UNORM: case B8G8R8A8_SRGB:
                        case B8G8R8X8_UNORM: case B8G8R8X8_SRGB: case R8_UNORM: break;
                        default: throw new IllegalArgumentException("Unsupported DDS DXGI format " + dxgi);
                    }
                    break;
                }
                default: throw new IllegalArgumentException("Unsupported DDS FourCC 0x" + Integer.toHexString(fourcc));
            }
        }
        byte[] out = new byte[w * h * 4];
        if (codec != null) {
            int bw = (w + 3) / 4, bh = (h + 3) / 4;
            int bs = (codec.equals("BC1") || codec.equals("BC4")) ? 8 : 16;
            if (d.length < off + (long) bw * bh * bs) throw new IllegalArgumentException("Truncated DDS blocks");
            byte[] blk = new byte[64];
            int p = off;
            for (int by = 0; by < bh; by++) for (int bx = 0; bx < bw; bx++, p += bs) {
                switch (codec) {
                    case "BC1": Bcdec.bc1(d, p, blk); break;
                    case "BC2": Bcdec.bc2(d, p, blk); break;
                    case "BC3": Bcdec.bc3(d, p, blk); break;
                    case "BC4": Bcdec.bc4(d, p, blk); break;
                    case "BC5": Bcdec.bc5(d, p, blk); break;
                    default: Bcdec.bc7(d, p, blk); break;
                }
                for (int y = 0; y < 4 && by * 4 + y < h; y++) for (int x = 0; x < 4 && bx * 4 + x < w; x++)
                    System.arraycopy(blk, (y * 4 + x) * 4, out, ((by * 4 + y) * w + bx * 4 + x) * 4, 4);
            }
            return pack(w, h, out);
        }
        // uncompressed
        int bpp, r, g, b, a; // byte offsets within pixel, -1 = absent
        if (dxgi != 0) {
            switch (dxgi) {
                case R8G8B8A8_UNORM: case R8G8B8A8_SRGB: bpp = 4; r = 0; g = 1; b = 2; a = 3; break;
                case B8G8R8A8_UNORM: case B8G8R8A8_SRGB: bpp = 4; r = 2; g = 1; b = 0; a = 3; break;
                case B8G8R8X8_UNORM: case B8G8R8X8_SRGB: bpp = 4; r = 2; g = 1; b = 0; a = -1; break;
                default: bpp = 1; r = g = b = 0; a = -1; break; // R8
            }
        } else {
            if ((pfFlags & 0x40) == 0 && (pfFlags & 0x20000) == 0) throw new IllegalArgumentException("DDS RGB bits");
            if (bits != 24 && bits != 32) throw new IllegalArgumentException("DDS RGB bits");
            bpp = bits / 8;
            r = maskByte(rm); g = maskByte(gm); b = maskByte(bm);
            a = (pfFlags & 1) != 0 ? maskByte(am) : -1;
            if (r < 0 || g < 0 || b < 0 || ((pfFlags & 1) != 0 && a < 0)) throw new IllegalArgumentException("Noncontiguous DDS mask");
        }
        if (d.length < off + (long) w * h * bpp) throw new IllegalArgumentException("Truncated DDS RGB");
        int p = off, o = 0;
        for (int i = 0; i < w * h; i++, p += bpp) {
            out[o++] = d[p + r]; out[o++] = d[p + g]; out[o++] = d[p + b]; out[o++] = a >= 0 ? d[p + a] : (byte) 255;
        }
        return pack(w, h, out);
    }

    private static int maskByte(int m) {
        switch (m) { case 0xff: return 0; case 0xff00: return 1; case 0xff0000: return 2; case 0xff000000: return 3; default: return -1; }
    }
}
