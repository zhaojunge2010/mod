import org.objectweb.asm.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class Fix {
  static ClassLoader cl;
  public static void main(String[] a) throws Exception {
    Path in = Paths.get(a[0]);
    cl = new java.net.URLClassLoader(new java.net.URL[]{in.toUri().toURL()}, ClassLoader.getPlatformClassLoader());
    List<Path> files;
    try (Stream<Path> s = Files.walk(in)) { files = s.filter(p -> p.toString().endsWith(".class")).collect(Collectors.toList()); }
    for (Path p : files) {
      byte[] b = Files.readAllBytes(p);
      ClassReader cr = new ClassReader(b);
      ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS) {
        @Override protected ClassLoader getClassLoader() { return cl; }
        @Override protected String getCommonSuperClass(String x, String y) {
          try { return super.getCommonSuperClass(x, y); } catch (Throwable t) { return "java/lang/Object"; }
        }
      };
      // upgrade to v52 so stack map frames are emitted
      cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
        @Override public void visit(int v, int acc, String n, String sig, String sup, String[] ifs) { super.visit(Opcodes.V1_8, acc, n, sig, sup, ifs); }
        @Override public MethodVisitor visitMethod(int acc, String n, String d, String sig, String[] ex) {
          return new MethodVisitor(Opcodes.ASM9, super.visitMethod(acc, n, d, sig, ex)) {
            @Override public void visitMethodInsn(int op, String owner, String name, String desc, boolean itf) {
              boolean isItf = itf;
              if (op == Opcodes.INVOKESTATIC && !owner.startsWith("[")) {
                try { isItf = Class.forName(owner.replace('/', '.'), false, cl).isInterface(); } catch (Throwable t) { }
              }
              super.visitMethodInsn(op, owner, name, desc, isItf);
            }
          };
        }
      }, ClassReader.SKIP_FRAMES);
      Files.write(p, cw.toByteArray());
    }
    System.out.println(files.size() + " classes rewritten");
  }
}
