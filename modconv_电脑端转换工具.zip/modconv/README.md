# ModConv — ModGlass 的「电脑 MOD → 手机模型」转换器（独立版）

从 ModGlass 1.8.26 APK 里单独提取出来的转换功能，可在电脑上直接运行（需要 Java 11+，Windows / macOS / Linux 均可），
不需要手机、不需要加载器、不涉及卡密授权。

转换结果与 App 内“转换”完全一致：一个文件夹，内含 `model.json` + `model.bin`（+ `conversion.log`）。

## 用法

```
java -jar modconv.jar --ini <模组主.ini> --id <角色ID> --out <输出目录> [选项]
```

| 参数 | 说明 |
|---|---|
| `--ini` | PC 模组的主 INI（其所在目录视为模组根目录，贴图/缓冲区按 INI 内相对路径读取） |
| `--id` | 目标角色 ID，10000000–10001999，例如 `10000112` |
| `--out` | 输出目录（须不存在，或加 `--replace`） |
| `--skeleton <目录>` | 角色骨骼库（App“同步 Unity2 骨骼”得到的 `unity2-skeletons/<角色>`）。不提供则按索引转换并回退到 `Body` |
| `--mapping "A=Body;B=Head"` | 部件映射，同 App 里的“部件映射” |
| `--fallback <名>` | 无骨骼库时的回退部件，默认 `Body` |
| `--no-variants` | 不展开 INI 里的按键/变体组合（默认展开，同 App） |
| `-v` | 打印转换日志 |

示例：

```
java -jar modconv.jar --ini "D:\Mods\Citlali\Citlali.ini" --id 10000107 --out out\Citlali -v
```

把输出文件夹放进 App 的模型目录（App 内“模型管理”导入）即可。

## 内容来源

- `com.gibox.tool.*`：APK 里的 GIBox 转换核心（`ModelConverter`、`ModConfig`、`ModLibrary`、`ModelManifest`、`Json` 等）。
  纯 Java，APK 自带的 `GIBox-MIT.txt` 声明为 MIT 许可（见 `LICENSE-GIBox-MIT.txt`，请保留）。
  jadx 无法还原其中主方法 `convert()` 的源码，所以这部分以**字节码**形式随 jar 提供（`tools/Fix.java` 是把 dex 转出的 class 修成标准 JVM 可加载格式的小工具）。
- `modconv.Main`：命令行入口（本工具编写）。
- `modconv.TextureDecoders` + `modconv.Bcdec`：手机上贴图由 arm64 原生库解码，电脑无法使用，所以用 Java 重写。
  BC1/2/3/4/5/7 来自 bcdec（MIT，ModGlass 使用的同一提交 80859ed）的移植，
  已用 C 原版对 6 种格式各 20 万随机块逐字节比对，全部一致。另支持 PNG 和常见未压缩 DDS。

## 已知限制（请留意）

1. **只提取了新版（GIBox / Unity2）转换器。** APK 里还有一套旧的 bundle 转换器（`Converter`/`FolderCompiler`），
   依赖游戏内抓取的骨骼数据和一个只有 arm64 二进制的闭源 INI 解析库，无法在电脑上独立运行，未包含。
2. 没有骨骼库时只能“按索引转换”，需进游戏验证；有骨骼库时更准。
3. 不支持 BC6H（HDR）贴图；BC4/BC5 单双通道贴图的通道展开方式（BC5 → R,G,B=0,A=255）是按 bcdec 原始输出推断的，
   手机原生库在这两种格式上的展开细节我无法在电脑上运行验证。普通漫反射（BC1/BC3/BC7）不受影响。
4. 只解码贴图的第 0 级 mip，不支持立方体/体积/数组 DDS（与原生库一致）。
5. 验证情况：用我构造的最小模组（1 个三角形 + 4×4 DXT1 贴图）跑通，输出 CRC/尺寸校验通过；
   没有用真实的大型原神模组测过，遇到失败请加 `-v` 看日志。
